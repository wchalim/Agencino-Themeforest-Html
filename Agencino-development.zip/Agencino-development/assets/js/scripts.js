/* --------------------------------------------------
    All javascript and jquery plugins activation
----------------------------------------------------- */
(function ($) {
	// Magnific Popup Style
	jQuery(".wc-hero-video-btn").magnificPopup({
		type: "iframe",
	});
	// Portfolio lightbox
	jQuery(".portfolio-lightbox").magnificPopup({
		type: "image",
	});

	/* Client logo slider*/
	new Swiper(".wc-logo-slide", {
		loop: true,
		slidesPerView: 2,
		loopFillGroupWithBlank: true,
		clickable: true,
		freeMode: true,
		autoplay: {
			delay: 2000,
		},
		breakpoints: {
			768: {
				slidesPerView: 3,
				spaceBetween: 40,
			},
			1024: {
				slidesPerView: 4,
				spaceBetween: 40,
			},
		},
	});

	/* Testimonial slider*/
	new Swiper(".testimonial-slide", {
		loop: true,
		slidesPerView: 1,
		clickable: true,
		spaceBetween: 20,
		breakpoints: {
			768: {
				slidesPerView: 1,
				spaceBetween: 500,
			},
			1024: {
				slidesPerView: 2,
			},
		},
	});

	/* Testimonial Style two*/
	new Swiper(".testimonial-style-2", {
		loop: true,
		slidesPerView: 1,
		clickable: true,
		spaceBetween: 20,
	});

	// Portfolio slider
	new Swiper(".wc-portfolio-slider-wrapper", {
		loop: true,
		slidesPerView: 1,
		spaceBetween: 20,
		breakpoints: {
			1024: {
				slidesPerView: 2,
				spaceBetween: 20,
			},
			1440: {
				slidesPerView: 2,
				spaceBetween: 20,
			},
			1441: {
				slidesPerView: 1,
				spaceBetween: 20,
			},
		},
	});

	/*--------------------------------------------------
    Portfolio activation
    ---------------------------------------------------*/
	jQuery(".wc-portfolio-section").imagesLoaded(function () {
		// portfolio activation
		const $grid = $(".portfolio-masonry");
		$grid.isotope({
			itemSelector: ".portfolio-item",
			percentPosition: true,
		});
		// portfolio filtering activation
		jQuery(".portfolio-filter li a").on("click", function (event) {
			var filterValue = $(this).attr("data-filter");
			$grid.isotope({ filter: filterValue });
			event.preventDefault();
		});
		// filter menu class addition
		jQuery(".portfolio-filter li").on("click", function (event) {
			$(this).siblings(".active").removeClass("active");
			$(this).addClass("active");
			event.preventDefault();
		});
	});
})(jQuery);

/* 
	Search form toggle
*/
(function () {
	const searchBtn = document.querySelector(".wc-search-toggle");
	const searchInput = document.querySelector(".wc-search-form-wrapper");
	searchBtn.addEventListener("click", function (e) {
		searchInput.classList.toggle("active");
	});

	// Hide search form on click outside
	document.addEventListener("click", (e) => {
		let buttonElement = e.target.closest(".wc-search-toggle");
		let formElement = e.target.closest(".wc-search-form-wrapper");
		if (formElement == null && buttonElement == null) {
			searchInput.classList.remove("active");
		}
	});
})();

(function () {
	const navToggleButton = document.querySelector(".wc-nav-toggle-button");
	const navPanel = document.querySelector(".hero-two-nav");
	const body = document.querySelector("body");
	navToggleButton.addEventListener("click", function (e) {
		navPanel.classList.toggle("show-nav");
	});

	// Hide search form on click outside
	document.addEventListener("click", (e) => {
		let toggleButtonElement = e.target.closest(".wc-nav-toggle-button");
		let navPanelElement = e.target.closest(".hero-two-nav");
		if (navPanelElement == null && toggleButtonElement == null) {
			navPanel.classList.remove("show-nav");
		}
	});
})();
